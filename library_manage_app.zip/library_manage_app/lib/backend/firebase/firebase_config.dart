import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyB7kIuQ_A1uHcpfOOyISmwLdjomnNGi95U",
            authDomain: "library-manage-app-chy1a4.firebaseapp.com",
            projectId: "library-manage-app-chy1a4",
            storageBucket: "library-manage-app-chy1a4.appspot.com",
            messagingSenderId: "555901361855",
            appId: "1:555901361855:web:970d42747e6532d605b00a"));
  } else {
    await Firebase.initializeApp();
  }
}
