import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'userlogin_widget.dart' show UserloginWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class UserloginModel extends FlutterFlowModel<UserloginWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for NAME widget.
  FocusNode? nameFocusNode;
  TextEditingController? nameTextController;
  String? Function(BuildContext, String?)? nameTextControllerValidator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController2;
  String? Function(BuildContext, String?)? textController2Validator;
  // State field(s) for UPASS widget.
  FocusNode? upassFocusNode;
  TextEditingController? upassTextController;
  late bool upassVisibility;
  String? Function(BuildContext, String?)? upassTextControllerValidator;
  // State field(s) for UCPASS widget.
  FocusNode? ucpassFocusNode;
  TextEditingController? ucpassTextController;
  late bool ucpassVisibility;
  String? Function(BuildContext, String?)? ucpassTextControllerValidator;

  @override
  void initState(BuildContext context) {
    upassVisibility = false;
    ucpassVisibility = false;
  }

  @override
  void dispose() {
    nameFocusNode?.dispose();
    nameTextController?.dispose();

    textFieldFocusNode?.dispose();
    textController2?.dispose();

    upassFocusNode?.dispose();
    upassTextController?.dispose();

    ucpassFocusNode?.dispose();
    ucpassTextController?.dispose();
  }
}
