import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'adminlogin_widget.dart' show AdminloginWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AdminloginModel extends FlutterFlowModel<AdminloginWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for ADNAME widget.
  FocusNode? adnameFocusNode;
  TextEditingController? adnameTextController;
  String? Function(BuildContext, String?)? adnameTextControllerValidator;
  // State field(s) for ADPASSD widget.
  FocusNode? adpassdFocusNode;
  TextEditingController? adpassdTextController;
  String? Function(BuildContext, String?)? adpassdTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    adnameFocusNode?.dispose();
    adnameTextController?.dispose();

    adpassdFocusNode?.dispose();
    adpassdTextController?.dispose();
  }
}
