package com.mycompany.librarymanageapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
